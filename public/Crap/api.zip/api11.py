import json
import os
import re
import requests
import copy
from configparser import ConfigParser, ExtendedInterpolation
from multiprocessing.pool import ThreadPool

from numpy import around
from pandas import DataFrame, to_numeric


class Das:
    def __init__(self, api_key=None):
        """
        :param api_key: 처음 실행시 발급받은 APIKEY(Token) 등록 또는 변경된 APIKEY 등록
        """
        self._config = ConfigParser(interpolation=ExtendedInterpolation())
        self.URL = "http://182.173.184.195/api/v1/{0}/{1}/{2}?api_key={3}"
        self.FILE_PATH = os.path.dirname(os.path.abspath(__file__)) + '\\config.ini'
        self._temp_data = []
        self._config_read(api_key)

    def _config_read(self, api_key):
        """
        config.ini 파일을 읽어 APIKEY을 가져오며, 파일이 없을경우 _make_config 호출
        :param api_key: 입력시 APIKEY 등록 config.ini 파일에 APIKEY를 저장
        """
        try:
            self._config.read(self.FILE_PATH)
            if api_key:
                self._config.set('default', 'apikey', api_key)
                with open(self.FILE_PATH, 'w') as configfile:
                    self._config.write(configfile)
        except Exception as e:
            print(e)
            self._make_config(api_key)
            self._config.read(self.FILE_PATH)

    def _make_config(self, api_key):
        """
        config.ini 가 없을경우 생성, APIKEY 등록
        :param api_key: APIKEY
        """
        if not api_key:
            api_key = input('저장된 APIKEY가 없습니다.\nAPIKEY:').strip().replace('"', "").replace("'", "")
        config_value = {'default': {'url': '182.173.184.195', 'version': 'v1', 'apikey': api_key}}
        for section in config_value:
            self._config.add_section(section)
            for key in config_value[section].keys():
                self._config.set(section, key, config_value[section][key])
        with open(os.path.dirname(os.path.abspath(__file__)) + '\\config.ini', 'w') as configfile:
            self._config.write(configfile)

    def _gen_uri_params(self, date_range, kwargs):
        """
        입력받은 검색기간(start, end)과 필터값을 파라미터로 변경
        :param date_range: [start, end]
        :param kwargs: 검색조건, 페이징, 정렬 등의 입력받은 필터
        :return: ['key=value',,,]
        """
        params = []
        if len(date_range) != 0:
            params.append('start={0}'.format(date_range[0]))
            params.append('end={0}'.format(date_range[-1]))
            for key, value in kwargs.items():
                params.append(key + "=" + str(value))
        return params

    def _gen_uris(self, collection, ids, date_range, kwargs):
        """
        입력받은 id 목록을 파라미터를 포함하여 uri를 완성하여 list 형태로 반환
        :param collection: collections, series, dataset 등
        :param ids: id 목록
        :param date_range: 검색기간 [start, end]
        :param kwargs: 검색조건, 페이징, 정렬 등의 입력받은 필터
        :return: ['http://url?key=value',,]
        """
        url_list = []
        params = self._gen_uri_params(date_range, kwargs)
        for _id in ids:
            url_list.append(self._get_url(collection, _id, '&'.join(params)))
        return url_list

    def _get_values(self, collection, args, kwargs):
        """
        tuple 로 입려받은 args 값에서 시계열 주기(M, D, W, w) 값과 검색기간(date)을
        구분하기 위한 함수
        :param collection: collections, series, dataset 등
        :param args: 최초 입력받은 검색기간, 시계열 주기
        :param kwargs: 검색조건, 페이징, 정렬 등의 입력받은 필터
        :return: uri 생성 함수를 호출 하여 결과값 반환(uri list)
        """
        date_range = []
        for arg in args[1:]:
            if len(arg) in (6,8) and re.match("[1-2]\d{3}\w\d", arg):
                date_range.append(arg)
            elif len(arg) == 1 and re.match("\w", arg):
                kwargs['freq'] == arg
        return self._gen_uris(collection, args[0], date_range, kwargs)

    def _get_url(self, _collection, _id, filters):
        """
        collection, id, 파라미터로 uri를 생성
        :param _collection: collections, series, dataset 등
        :param _id: series, categories, dataset 등의 id
        :param filters: 파라미터
        :return: [id, uri]
        """
        uri = self.URL.format(_id.split('_')[0].split('-')[0], _collection, _id, self._config['default']['apikey'])
        if len(filters) != 0:
            uri += '&' + filters
        return [_id, uri]

    def _request_get(self, uri):
        """
        입력받은 uri에 headers(인증정보)를 포함하여 호출후 response text를 json으로 변환
        :param uri: 호출할 uri
        :return: [id, response]
        """
        headers = {'Authorization': 'Token ' + self._config['default']['apikey']}
        try:
            res = requests.get(uri[1], headers=headers) # , verify=False)
        except requests.exceptions.HTTPError as e:
            res = {'uri': uri[1], 'msg': 'request get error', 'error': e}
        try:
            data = json.loads(res.text)
        except ValueError:
            data = {'uri': uri[1], 'msg': 'JSON load error', 'res': res.text}
            print(data)
        self._temp_data.append([uri[0], data])
        return [uri[0], data]

    def _change_digits(self, data, digits):
        """
        DataFrame의 value 컬럼의 소숫점 자리수를 변경하여 반환
        :param data: DataFrame
        :param digits: 수숫점 자릿수
        :return: DataFrame
        """
        try:
            return around(data.value, decimals=int(digits)).value
        except:
            return data

    def _obs_to_df(self, _value, _filters):
        """
        Observation의 시계열 데이터를 DataFrame으로 변경한 후
        value 컬럼을 string type 에서 float type 으로 변경
        :param _value: json type의 Observation 데이터
        :param _filters: 검색조건, 페이징, 정렬 등의 입력받은 필터
        :return: DataFrame
        """
        df = DataFrame(list(_value[1]['observations']))
        if type(df).__name__ is 'DataFrame':
            df.value = to_numeric(df.value, errors='coerce')
            if 'digits' in _filters:
                df = self._change_digits(df, _filters['digits'])
            df.columns = ['period', _value[0]]
        return df

    def _meta_to_df(self, _value):
        """
        json type의 데이터를 DataFrame으로 변환
        :param _value:
        :return: DataFrame
        """
        try:
            return DataFrame(_value)
        except:
            return _value

    def merge_data(self, resp, _filters):
        """
        시계열 데이터들을 하나의 DataFrame으로 통합하는 함수
        :param resp: json type의 데이터 목록
        :param _filters:검색조건, 페이징, 정렬 등의 입력받은 필터
        :return:
        """
        _total = 0
        for _value in resp:
            if 'observations' in _value[1]:
                df = self._obs_to_df(_value, _filters)
                if type(_total).__name__ != 'int':
                    _total = _total.merge(df, how='outer')
                else:
                    _total = copy.deepcopy(df)
            else:
                df = self._meta_to_df(_value[1])
                if type(_total).__name__ != 'int':
                    _total.append(df)
                else:
                    _total = [[df]]
        return _total

    def run(self, _values):
        """
        요청받은 id 값이 여러 개인 경우를 고려하여 multi thread 구현
        :param _values: uri 목록
        :return: 결과 목록
        """
        self._temp_data = []
        pool = ThreadPool()
        return pool.map(self._request_get, _values)

    def series(self, *args, **kwargs):
        """
        observation 데이터요청 함수
        :param args: id 목록, 검색기간, 시계열 주기
        :param kwargs: 검색조건, 페이징, 정렬 등의 입력받은 필터
        :return: DataFrame
        """
        resp = self.run(self._get_values('observations', args, kwargs))
        return self.merge_data(resp, kwargs)

    def series_meta(self, *args, **kwargs):
        """
        observation meta 정보요청 함수
        """
        resp = self.run(self._get_values('series', args, kwargs))
        return self.merge_data(resp, kwargs)

    def categories(self, *args, **kwargs):
        """
        category 정보 요청 함수
        """
        resp = self.run(self._get_values('categories', args, kwargs))
        return self.merge_data(resp, kwargs)

    def dataset(self, *args, **kwargs):
        """
        dataset 하위 모든 시계열 data 요청 함수
        """
        resp = self.run(self._get_values('dataset', args, kwargs))
        return self.merge_data(resp, kwargs)

    def dataset_meta(self, *args, **kwargs):
        """
        dataset meta 정보요청 함수
        """
        resp = self.run(self._get_values('dataset', args, kwargs))
        return self.merge_data(resp, kwargs)

    def mytable(self, *args, **kwargs):
        """
        mytable data 요청 함수
        """
        resp = self.run(self._get_values('mytable', args, kwargs))
        return self.merge_data(resp, kwargs)

if __name__ == '__main__':
    o = Das()
    urls = ['OECD-QNA-JPN-GFSPB-CARSA-A', 'OECD-QNA-JPN-GFSPB-CARSA-Q', 'OECD-QNA-JPN-GFSPR-CARSA-A']
    print(o.series(urls, "20170101", "20470101", digits=5, test="5"))

